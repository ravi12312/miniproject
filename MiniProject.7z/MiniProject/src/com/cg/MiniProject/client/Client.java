package com.cg.MiniProject.client;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;



public class Client {

	public static void main(String[] args) {
		System.out.println("Welcome to Payment Wallet");
		System.out.println("Enter Any one option from the below Options");
		System.out.println("1.Create Account");
		System.out.println("2.Show Balance");
		System.out.println("3.Deposit");
		System.out.println("4.Withdraw");
		System.out.println("5.Fund Transfer");
		System.out.println("6.Print Transactions");
		System.out.println("7.Exit");
		int choice;
		Scanner sc = new Scanner(System.in);
		choice = sc.nextInt();
		switch (choice) {
		case 1:
	
			break;
		case 2:

			break;
		case 3:

			break;
		case 4:

			break;
		case 5:

			break;
		case 6:

			break;
		case 7:
			System.exit(0);
			break;

			
		}
	}
}
		
		
