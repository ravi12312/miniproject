package com.cg.MiniProject.bean;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.Transient;

@Entity
@Table(name = "Wallet_Table")
public class WalletBean {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int wid;
	
	private double transactionamt;
	
	private int transactiontype;// 1- depostit 2- withdraw 3-fund transfer
	
	@Temporal(TemporalType.DATE)
	private Date transactiondate;
	
	@Transient
	private AccountBean transferbean; // in case of transfer

	public int getWid() {
		return wid;
	}

	public void setWid(int wid) {
		this.wid = wid;
	}

	public double getTransactionamt() {
		return transactionamt;
	}

	public void setTransactionamt(double transactionamt) {
		this.transactionamt = transactionamt;
	}

	public int getTransactiontype() {
		return transactiontype;
	}

	public void setTransactiontype(int transactiontype) {
		this.transactiontype = transactiontype;
	}

	public Date getTransactiondate() {
		return transactiondate;
	}

	public void setTransactiondate(Date transactiondate) {
		this.transactiondate = transactiondate;
	}

	public AccountBean getTransferbean() {
		return transferbean;
	}

	public void setTransferbean(AccountBean transferbean) {
		this.transferbean = transferbean;
	}

	@Override
	public String toString() {
		return "WalletBean [wid=" + wid + ", transactionamt=" + transactionamt
				+ ", transactiontype=" + transactiontype + ", transactiondate="
				+ transactiondate + ", transferbean=" + transferbean + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + wid;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		WalletBean other = (WalletBean) obj;
		if (wid != other.wid)
			return false;
		return true;
	}
	
	
}
