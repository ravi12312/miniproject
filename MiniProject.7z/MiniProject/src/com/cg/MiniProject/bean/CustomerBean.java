package com.cg.MiniProject.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "customer_table")
public class CustomerBean {

	@Id
	@Column(name="cust_id")
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cid;
	
	@Column(name="First_name")
	private String firstname;
	
	@Column(name="Last_name")
	private String lastname;
	
	@Column(name="Address")
	private String address;
	
	@Column(name="PAN_Number")
	private String pan;
	
	@Column(name="Age")
	private int age;
	
	
	@Id
	@Column(name="Phone_Number")
	private String phonenumber;
	
	
	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getFirstname() {
		return firstname;
	}

	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}

	public String getLastname() {
		return lastname;
	}

	public void setLastname(String lastname) {
		this.lastname = lastname;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPan() {
		return pan;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getPhonenumber() {
		return phonenumber;
	}

	public void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	@Override
	public String toString() {
		return "CustomerBean [cid=" + cid + ", firstname=" + firstname
				+ ", lastname=" + lastname + ", address=" + address + ", pan="
				+ pan + ", age=" + age + ", phonenumber=" + phonenumber + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + cid;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerBean other = (CustomerBean) obj;
		if (cid != other.cid)
			return false;
		return true;
	}

}
