package com.cg.MiniProject.bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "Bank_account")
public class AccountBean {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int accountId;
	
	private double balance;
	
	@Temporal(TemporalType.DATE)
	private Date dateofopening;
	
	
	private double initialdeposit;
	
	@OneToMany(cascade=CascadeType.ALL, fetch=FetchType.EAGER)
	List<WalletBean> transactions = new ArrayList<WalletBean>();

	public int getAccountId() {
		return accountId;
	}

	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Date getDateofopening() {
		return dateofopening;
	}

	public void setDateofopening(Date dateofopening) {
		this.dateofopening = dateofopening;
	}

	public double getInitialdeposit() {
		return initialdeposit;
	}

	public void setInitialdeposit(double initialdeposit) {
		this.initialdeposit = initialdeposit;
	}

	public List<WalletBean> getTransactions() {
		return transactions;
	}

	public void setTransactions(List<WalletBean> transactions) {
		this.transactions = transactions;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + accountId;
		return result;
	}

	@Override
	public String toString() {
		return "AccountBean [accountId=" + accountId + ", balance=" + balance
				+ ", dateofopening=" + dateofopening + ", initialdeposit="
				+ initialdeposit + ", transactions=" + transactions + "]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AccountBean other = (AccountBean) obj;
		if (accountId != other.accountId)
			return false;
		return true;
	}

	private void Add(WalletBean wb){
		this.transactions.add(wb);
	}
	

}
