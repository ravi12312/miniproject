package com.cg.MiniProject.service;

import java.math.BigInteger;

import com.cg.MiniProject.dao.DAOI;
import com.cg.MiniProject.dao.DAOImpl;

public class ServiceImpl implements ServiceI {

	DAOI dao = new DAOImpl();
	
}
