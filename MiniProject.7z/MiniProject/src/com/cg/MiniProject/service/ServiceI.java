package com.cg.MiniProject.service;

import java.math.BigInteger;


public interface ServiceI {

	
}
