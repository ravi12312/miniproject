package com.cg.MiniProject.dao;

public class DAOImpl implements DAOI {

	@Override
	public boolean createAccount() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean showBalance() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deposit() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean withdraw() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean fundtransfer() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean printtransactions() {
		// TODO Auto-generated method stub
		return false;
	}

	
}
