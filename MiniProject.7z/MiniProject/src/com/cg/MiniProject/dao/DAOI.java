package com.cg.MiniProject.dao;

public interface DAOI {

	public boolean createAccount();
	public boolean showBalance();
	public boolean deposit();
	public boolean withdraw();
	public boolean fundtransfer();
	public boolean printtransactions();
}
